(function(){
  window['optimizely'] = window['optimizely'] || [];
  window['optimizely'].push(['activateGeoDelayedExperiments', {
    'location':{
      'city': "LAGOS",
      'continent': "AF",
      'country': "NG",
      'region': ""
    },
    'ip':"129.56.103.136"
  }]);
})
//
()

;